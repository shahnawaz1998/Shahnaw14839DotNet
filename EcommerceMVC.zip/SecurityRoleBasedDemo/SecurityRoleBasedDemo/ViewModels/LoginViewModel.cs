﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace SecurityRoleBasedDemo.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage ="User Name required!")]
        public string UserName { get; set; }
      
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        public bool RememberMe { get; set; }
    }

}
