﻿select * from [dbo].[AspNetUsers];
select * from [dbo].[AspNetRoles];
select * from [dbo].[AspNetUserRoles];

delete from [dbo].[AspNetUsers] 
where FullName = 'Admin';

delete from [dbo].[AspNetRoles] where Name = 'admin';